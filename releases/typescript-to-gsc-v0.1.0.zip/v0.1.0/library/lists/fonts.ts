const fonts = [
	'objective'
];

export default fonts;
