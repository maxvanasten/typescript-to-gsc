# Programmable quests that check for certain conditions to be met

