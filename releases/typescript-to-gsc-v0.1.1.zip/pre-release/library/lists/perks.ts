enum Perks {
	juggernog = `"specialty_armorvest"`,
	quick_revive = `"specialty_quickrevive"`,
	speed_cola = `"specialty_fastreload"`,
	double_tap = `"specialty_rof"`,
	stamin_up = `"specialty_longersprint"`,
	deadshot = `"specialty_deadshot"`,
	mule_kick = `"specialty_additionalprimaryweapon"`,
	electric_cherry = `"specialty_grenadepulldeath"`
}

export default Perks;
